.. _basics.dispatch:

*******************************
Writing custom array containers
*******************************

.. automodule:: numpy.doc.dispatch

