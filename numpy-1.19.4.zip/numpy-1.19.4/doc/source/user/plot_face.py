from scipy import misc
import matplotlib.pyplot as plt

img = misc.face()
plt.imshow(img)
